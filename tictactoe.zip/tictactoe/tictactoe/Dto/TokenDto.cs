﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace tictactoe.Dto
{
    public class TokenDto
    {
        public string player { get; set; }
        public int row { get; set; }
        public int col { get; set; }

    }
}
