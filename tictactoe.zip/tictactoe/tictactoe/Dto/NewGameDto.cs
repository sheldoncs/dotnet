﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace tictactoe.Dto
{
    public class NewGameDto
    {
        public int game_id { get; set; }
    }
}
