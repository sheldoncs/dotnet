﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace tictactoe.Dto
{
    public class GameDto
    {
        public int game_id { get; set; }
        public string PlayerA { get; set; }
        public string PlayerB { get; set; }


    }
}
